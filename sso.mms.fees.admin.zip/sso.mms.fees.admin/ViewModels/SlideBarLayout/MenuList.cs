﻿namespace sso.mms.fees.admin.ViewModels.SlideBarLayout
{

    public class MenuList
    {
        public string? Pages { get; set; }
        public List<MenuItems>? MenuItems { get; set; }

    }

    public class MenuItems
    {
        public string? Title { get; set; }
        public string? Link { get; set; }
        public string? Icon { get; set; }
    }
}
