﻿using AntDesign;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using sso.mms.fees.admin.ViewModels.SlideBarLayout;
using sso.mms.helper.Configs;

namespace sso.mms.fees.admin.Data
{
    public class MenuListService
    {

        public MenuListService()
        {

        }

        public List<MenuList> MenuList = new List<MenuList>
          {
            new MenuList {
                Pages = "riskExposure",
                MenuItems = new List<MenuItems> {
                    new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "/riskExposure/index",Icon="fa-regular fa-paste" },
                    new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "/riskExposure/formula",Icon="fa-solid fa-square-root-variable" },
                    new MenuItems { Title = "รายการขอเบิก" , Link = "/riskExposure/withDrawRequestList",Icon="fa-solid fa-list" },
                    new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "/riskExposure/paymentOrdersList",Icon="fa-regular fa-square-check" },
                    new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "/riskExposure/disburseMentList",Icon="fa-solid fa-clock-rotate-left" },
                    new MenuItems { Title = "รายงาน" , Link = "/riskExposure/reports",Icon="fa-regular fa-folder-closed" },
                    new MenuItems { Title = "ผลการประมวลด้วย AI" , Link = "/riskExposure/progressAI",Icon="fa-regular fa-tasks" }
                }
            },
            new MenuList {
                Pages = "adjRW",
                MenuItems = new List<MenuItems> {
                    new MenuItems { Title = "จัดการวงเงินงบปรมาณ" , Link = "/adjRW/index",Icon="fa-solid fa-dollar-sign" },
                    new MenuItems { Title = "กำหนดอัตราค่าบริการ" , Link = "/adjRW/SetServiceRate",Icon="fa-regular fa-square-plus" },
                    new MenuItems { Title = "กำหนดประเภทสถานพยาบาล" , Link = "/adjRW/DetermineTypeHospital" ,Icon="fa-regular fa-hospital"},
                    new MenuItems { Title = "รายการขอเบิก" , Link = "/adjRW/WithdrawalRequestList",Icon="fa-solid fa-list-check"},
                    new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "/adjRW/PaymentOrderList" ,Icon="fa-regular fa-square-check"},
                    new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "/adjRW/DisbursementHistory",Icon="fa-solid fa-clock-rotate-left" },
                    new MenuItems { Title = "รายงาน" , Link = "/adjRW/Report", Icon="fa-regular fa-folder-open" }
                }
            },
           new MenuList {
               Pages = "organTransplantation",
               MenuItems = new List<MenuItems> {
               new MenuItems { Title = "รายการรับแจ้ง" , Link = "/organTransplantation/index",Icon="fa-brands fa-bitcoin" },
               new MenuItems { Title = "สร้างคำสั่งจ่าย" , Link = "/organTransplantation/createPaymentOrder",Icon="fa-regular fa-square-plus"  },
               new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "/organTransplantation/disbursementHistory",Icon="fa-solid fa-hospital" },
               new MenuItems { Title = "ประวัติรายการที่ไม่อนุมัติ" , Link = "/organTransplantation/unapprovalLists",Icon="fa-solid fa-square-check" },
               new MenuItems { Title = "รายงาน" , Link = "/organTransplantation/report", Icon="fa-solid fa-folder-open" },
               new MenuItems { Title = "กำหนดอัตราจ่าย" , Link = "/organTransplantation/payrate", Icon="fa-solid fa-clock-rotate-left" },

               }
           },
            new MenuList {
                Pages = "disability",
                MenuItems = new List<MenuItems> {
                    new MenuItems { Title = "นำเข้าข้อมูล" , Link = "/disability/index",Icon="fa-brands fa-bitcoin" },
                    new MenuItems { Title = "งานวินิจฉัย" , Link = "/disability/diagnosis",Icon="fa-regular fa-square-plus" },
                    new MenuItems { Title = "ขอเอกสารเพิ่มเติม" , Link = "/disability/requestDocuments" ,Icon="fa-solid fa-hospital"},
                    new MenuItems { Title = "งานสั่งจ่าย" , Link = "/disability/workOrders",Icon="fa-solid fa-list-check"},
                    new MenuItems { Title = "ประวัติการเบิก" , Link = "/disability/withdrawalHistory" ,Icon="fa-solid fa-square-check"},
                    new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "/disability/reportPay",Icon="fa-solid fa-clock-rotate-left" },
                }
            },
            new MenuList {
                Pages = "promoteHealth",
                MenuItems = new List<MenuItems> {
                    new MenuItems { Title = "กำหนดรายการตรวจสุขภาพ" , Link = "/promoteHealth/index",Icon="fa-solid fa-dollar-sign" },
                    new MenuItems { Title = "รายการขอเบิก" , Link = "/promoteHealth/withdrawalRequestList",Icon="fa-solid fa-list-check" },
                    new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "/promoteHealth/paymentOrdersList",Icon="fa-regular fa-square-check"},
                    new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "/promoteHealth/disbursementHistory",Icon="fa-solid fa-clock-rotate-left" },
                    new MenuItems { Title = "รายงาน" , Link = "/promoteHealth/reports", Icon="fa-regular fa-folder-open" }
                }
            },
           new MenuList {
                Pages = "HealthPromoVaccination",
                MenuItems = new List<MenuItems> {
                    new MenuItems { Title = "รายการรับเเจ้ง" , Link = "/HealthPromoVaccination/index",Icon="fa-solid fa-dollar-sign" },
                    new MenuItems { Title = "สร้างคำสั่งจ่าย" , Link = "/HealthPromoVaccination/CreatePaymentOrder",Icon="fa-solid fa-list-check" },
                    new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "/HealthPromoVaccination/paymentOrdersList",Icon="fa-regular fa-square-check"},
                    new MenuItems { Title = "ประวัติรายการที่ไม่อนุมัติ" , Link = "/HealthPromoVaccination/disbursementHistory",Icon="fa-solid fa-clock-rotate-left" },
                    new MenuItems { Title = "รายงาน" , Link = "/HealthPromoVaccination/reports", Icon="fa-regular fa-folder-open" }
                }
            },
            new MenuList {
                Pages = "test1",
                MenuItems = new List<MenuItems> {
                    new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "" },
                    new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "" },
                    new MenuItems { Title = "รายการขอเบิก" , Link = "" },
                    new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "" },
                    new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                    new MenuItems { Title = "รายงาน" , Link = "" }
                }
            },
            new MenuList {
                        Pages = "test1",
                        MenuItems = new List<MenuItems> {
                            new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "" },
                            new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "" },
                            new MenuItems { Title = "รายการขอเบิก" , Link = "" },
                            new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "" },
                            new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                            new MenuItems { Title = "รายงาน" , Link = "" }
                        }
                    },
            new MenuList {
                        Pages = "test1",
                        MenuItems = new List<MenuItems> {
                            new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "" },
                            new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "" },
                            new MenuItems { Title = "รายการขอเบิก" , Link = "" },
                            new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "" },
                            new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                            new MenuItems { Title = "รายงาน" , Link = "" }
                        }
                    },
            new MenuList {
                            Pages = "test1",
                            MenuItems = new List<MenuItems> {
                                new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "" },
                                new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "" },
                                new MenuItems { Title = "รายการขอเบิก" , Link = "" },
                                new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "" },
                                new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                                new MenuItems { Title = "รายงาน" , Link = "" }
                            }
                    },
            new MenuList {
                            Pages = "test1",
                            MenuItems = new List<MenuItems> {
                                new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "" },
                                new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "" },
                                new MenuItems { Title = "รายการขอเบิก" , Link = "" },
                                new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "" },
                                new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                                new MenuItems { Title = "รายงาน" , Link = "" }
                            }
                    },
            new MenuList {
                        Pages = "test1",
                        MenuItems = new List<MenuItems> {
                            new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "" },
                            new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "" },
                            new MenuItems { Title = "รายการขอเบิก" , Link = "" },
                            new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "" },
                            new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                            new MenuItems { Title = "รายงาน" , Link = "" }
                        }
                    },
            new MenuList {
                        Pages = "test1",
                        MenuItems = new List<MenuItems> {
                            new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "" },
                            new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "" },
                            new MenuItems { Title = "รายการขอเบิก" , Link = "" },
                            new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "" },
                            new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                            new MenuItems { Title = "รายงาน" , Link = "" }
                        }
                    },
            new MenuList {
                        Pages = "test1",
                        MenuItems = new List<MenuItems> {
                            new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "" },
                            new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "" },
                            new MenuItems { Title = "รายการขอเบิก" , Link = "" },
                            new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "" },
                            new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                            new MenuItems { Title = "รายงาน" , Link = "" }
                        }
                    },
            new MenuList {
                        Pages = "test1",
                        MenuItems = new List<MenuItems> {
                            new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "" },
                            new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "" },
                            new MenuItems { Title = "รายการขอเบิก" , Link = "" },
                            new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "" },
                            new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                            new MenuItems { Title = "รายงาน" , Link = "" }
                        }
                    },
            new MenuList {
                        Pages = "test1",
                        MenuItems = new List<MenuItems> {
                            new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "" },
                            new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "" },
                            new MenuItems { Title = "รายการขอเบิก" , Link = "" },
                            new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "" },
                            new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                            new MenuItems { Title = "รายงาน" , Link = "" }
                        }
                    },
            new MenuList {
                        Pages = "organMaintenance",
                        MenuItems = new List<MenuItems> {
                            new MenuItems { Title = "บันทึกค่าบำรุงรักษาอวัยวะ" , Link = "/organMaintenance/index" },
                            new MenuItems { Title = "รายการรับแจ้ง" , Link = "" },
                            new MenuItems { Title = "สร้างคำสั่งจ่าย" , Link = "/organMaintenance/createPaymentOrder" },
                            new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                            new MenuItems { Title = "ประวัติรายการที่ไม่อนุมัติ" , Link = "" },
                            new MenuItems { Title = "รายงาน" , Link = "" },
                            new MenuItems { Title = "กำหนดอัตราจ่าย" , Link = "" }
                        }
                    },
            new MenuList {
                        Pages = "test1",
                        MenuItems = new List<MenuItems> {
                            new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "" },
                            new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "" },
                            new MenuItems { Title = "รายการขอเบิก" , Link = "" },
                            new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "" },
                            new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                            new MenuItems { Title = "รายงาน" , Link = "" }
                        }
                    },
            new MenuList {
                        Pages = "Dental",
                        MenuItems = new List<MenuItems> {
                            new MenuItems { Title = "อนุญาตการใช้รถทันตกรรม" , Link = "/Dental/index" },
                            new MenuItems { Title = "รายการรับเเจ้ง" , Link = "/Dental/NotificationList" },
                            new MenuItems { Title = "สร้างคำสั่งจ่าย" , Link = "/Dental/PaymentOrder" },
                            new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "/Dental/DisBurseMentList" },
                            new MenuItems { Title = "ประวัติรายการที่ไม่อนุมัติ" , Link = "/Dental/DisapprovedTranHistory" },
                            new MenuItems { Title = "รายงาน" , Link = "/Dental/Report" }
                        }
                    },
            new MenuList {
                        Pages = "test1",
                        MenuItems = new List<MenuItems> {
                            new MenuItems { Title = "กำหนดคะแนนโรคเรื้อรัง" , Link = "" },
                            new MenuItems { Title = "กำหนดสูตรการคำนวณ" , Link = "" },
                            new MenuItems { Title = "รายการขอเบิก" , Link = "" },
                            new MenuItems { Title = "รายการใบคำสั่งจ่าย" , Link = "" },
                            new MenuItems { Title = "ประวัติการเบิกจ่าย" , Link = "" },
                            new MenuItems { Title = "รายงาน" , Link = "" }
                        }
                    }
        };

        public MenuList GetMenuLists(string pageName)
        {
            var findMenuList = MenuList.FirstOrDefault(x => x.Pages == pageName);
            if (findMenuList != null)
            {
                return findMenuList;
            }
            else
            {
                return new MenuList();
            }
        }
    }
}
